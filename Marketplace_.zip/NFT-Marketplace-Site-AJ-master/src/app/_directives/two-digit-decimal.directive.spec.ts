import { TwoDigitDecimalDirective } from './two-digit-decimal.directive';

describe('TwoDigitDecimalDirective', () => {
  it('should create an instance', () => {
    const directive = new TwoDigitDecimalDirective();
    expect(directive).toBeTruthy();
  });
});
