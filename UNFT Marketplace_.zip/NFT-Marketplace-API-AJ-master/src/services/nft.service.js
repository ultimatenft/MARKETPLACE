/* eslint-disable no-unused-vars */
const ethers = require('ethers');
const httpStatus = require('http-status-codes');
const { Nft, Transaction } = require('../models');
const ApiError = require('../utils/ApiError');
const config = require('../config/config');
const emailService = require('./email.service');
const transactionService = require('./transaction.service');

const { contractAddress } = config;

/**
 * Create a nft
 * @param {Object} nftBody
 * @returns {Promise<Nft>}
 */
const createNft = async (nftBody, user) => {
  Object.assign(nftBody, { currentOwner: user.id, owner: user.id });
  const nft = await Nft.create(nftBody);
  return nft;
};

/**
 * Get all nfts
 * @returns {Promise<Nft>}
 */
const getAllNfts = async () => {
  let nfts = [];
  nfts = await Nft.find({})
    .sort([['createdAt', 'desc']])
    .populate('currentOwner');
  return nfts;
};

/**
 * Get all available nfts
 * @returns {Promise<Nft>}
 */
const getAllAvailableNfts = async (isFeatured) => {
  let nfts = [];
  const query = isFeatured === 'true' ? { status: 'AVAILABLE', isFeatured } : { status: 'AVAILABLE' };
  nfts = await Nft.find(query)
    .sort([['createdAt', 'desc']])
    .populate('currentOwner');
  return nfts;
};

/**
 * Query for nfts
 * @param {Object} filter - Mongo filter
 * @param {Object} options - Query options
 * @param {string} [options.sortBy] - Sort option in the format: sortField:(desc|asc)
 * @param {number} [options.limit] - Maximum number of results per page (default = 10)
 * @param {number} [options.page] - Current page (default = 1)
 * @returns {Promise<QueryResult>}
 */
const queryNfts = async (filter, options) => {
  const nfts = await Nft.paginate(filter, options);
  return nfts;
};

/**
 * Get nft by id
 * @param {ObjectId} id
 * @returns {Promise<Nft>}
 */
const getNftById = async (id) => {
  return Nft.findById(id).populate('currentOwner');
};

/**
 * Update nft by id
 * @param {ObjectId} nftId
 * @param {Object} updateBody
 * @returns {Promise<Nft>}
 */
const updateNftById = async (nftId, updateBody) => {
  const nft = await getNftById(nftId);
  if (!nft) {
    throw new ApiError(httpStatus.StatusCodes.NOT_FOUND, 'Nft not found');
  }
  Object.assign(nft, updateBody);
  await nft.save();
  return nft;
};

/**
 * Delete nft by id
 * @param {ObjectId} nftId
 * @returns {Promise<Nft>}
 */
const deleteNftById = async (nftId) => {
  const nft = await getNftById(nftId);
  if (!nft) {
    throw new ApiError(httpStatus.StatusCodes.NOT_FOUND, 'Nft not found');
  }
  await nft.remove();
  return nft;
};

/**
 * check is nft available or not
 * @returns {Promise<Nft>}
 */
const checkiSNftAvailable = async (nftId, userId) => {
  const nft = await Nft.findById(nftId);
  if (nft && nft.status !== 'AVAILABLE') {
    throw new ApiError(httpStatus.StatusCodes.NOT_FOUND, 'Nft is not available for sell');
  }
  if (nft.status === 'AVAILABLE') {
    const date = new Date();
    Object.assign(nft, {
      status: 'LOCKED',
      lockedUserId: userId,
      lockedExpiry: new Date(date.getTime() + 3 * 60000).toUTCString(),
    });
    await nft.save();
    return nft;
  }
};

/**
 * release nft for sell
 * @returns {Promise<Nft>}
 */
const releaseNFT = async (nftId) => {
  const nft = await Nft.findById(nftId);
  if (!nft) {
    throw new ApiError(httpStatus.StatusCodes.NOT_FOUND, 'Nft is not available for sell');
  }

  Object.assign(nft, {
    status: 'AVAILABLE',
    lockedUserId: undefined,
    lockedExpiry: undefined,
  });
  await nft.save();
  return nft;
};

/**
 * Get nft by customerTxnHash
 * @returns {Promise<Nft>}
 */
const findNFTbyTxn = async (customerTxnHash, amount) => {
  const provider = new ethers.providers.JsonRpcProvider('https://rinkeby.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161');
  try {
    const txReceipts = await provider.getTransaction(customerTxnHash);
    const amountFromTxn = txReceipts.value.toString();
    const originalAmt = amount * 10 ** 18;
    if (
      txReceipts &&
      txReceipts.blockNumber &&
      txReceipts.to.toLowerCase() === contractAddress.toLowerCase() &&
      amountFromTxn === originalAmt.toString()
    ) {
      const nft = await Transaction.findOne({ txnHash: customerTxnHash });
      if (nft) {
        throw new ApiError(httpStatus.StatusCodes.BAD_REQUEST, 'Invalid Transaction Id');
      } else {
        return txReceipts;
      }
    }
    throw new ApiError(httpStatus.StatusCodes.BAD_REQUEST, 'Invalid Transaction Id');
  } catch (error) {
    throw new ApiError(httpStatus.StatusCodes.BAD_REQUEST, error.message);
  }
};

/**
 * buy a nft
 * @param {Object} nftBody
 * @returns {Promise<Nft>}
 */
const buyNft = async (nftBody) => {
  await findNFTbyTxn(nftBody.transactionDetail.transactionHash, nftBody.total);
  const nftDetail = await Nft.findById(nftBody.nft).populate('currentOwner');
  const nft = await updateNftById(nftBody.nft, {
    status: 'SOLD',
    currentOwner: nftBody.user,
    tokenId: nftBody.tokenId,
    currentOwnerWalletAddress: nftBody.currentOwnerWalletAddress,
    lockedUserId: undefined,
    lockedExpiry: undefined,
  });
  await transactionService.createTransaction({
    nft: nft.id,
    user: nftBody.user,
    type: 'BUY',
    amount: nftBody.total,
    txnHash: nftBody.transactionDetail.transactionHash,
    transactionDetail: nftBody.transactionDetail,
  });
  await transactionService.createTransaction({
    nft: nft.id,
    user: nftDetail.currentOwner.id,
    type: 'SELL',
    amount: nftBody.sellerFee,
    txnHash: nftBody.transactionDetail.transactionHash,
    transactionDetail: nftBody.transactionDetail,
  });
  await transactionService.createTransaction({
    nft: nft.id,
    user: nftDetail.currentOwner.id,
    type: 'COMMISSION',
    amount: nftBody.ownerFee,
    percentage: nftBody.platformFee,
    txnHash: nftBody.transactionDetail.transactionHash,
    transactionDetail: nftBody.transactionDetail,
  });

  await emailService.purchaseNFTEmail(nft.currentOwner, nft);
  await emailService.soldNFTEmail(nftDetail.currentOwner, nft);
  return nft;
};

/**
 * release nft from in progress if not sold : cron Job
 * @returns {Promise<Nft>}
 */
const releaseInProgressNftCron = async () => {
  const date = new Date().toUTCString();
  const nfts = await Nft.updateMany(
    { status: 'LOCKED', lockedExpiry: { $lte: date } },
    {
      status: 'AVAILABLE',
      lockedUserId: undefined,
      lockedExpiry: undefined,
    }
  );
  return nfts;
};

/**
 * search nft
 * @returns {Promise<Nft>}
 */
const searchNft = async (term) => {
  const nfts = await Nft.find({ status: 'AVAILABLE', name: { $regex: term, $options: 'i' } }).populate('currentOwner');
  return nfts;
};

module.exports = {
  createNft,
  getAllNfts,
  getAllAvailableNfts,
  queryNfts,
  getNftById,
  updateNftById,
  deleteNftById,
  checkiSNftAvailable,
  releaseNFT,
  buyNft,
  releaseInProgressNftCron,
  searchNft,
};
