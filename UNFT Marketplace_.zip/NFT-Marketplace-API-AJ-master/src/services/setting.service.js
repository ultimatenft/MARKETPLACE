// const httpStatus = require('http-status');
const { Setting } = require('../models');
// const ApiError = require('../utils/ApiError');

const getSettingInfo = async () => {
  const settings = await Setting.findOne({});
  return settings;
};

const updateSettingInfo = async (settingBody) => {
  let setting = await getSettingInfo();
  if (setting) {
    Object.assign(setting, settingBody);
    setting.save();
  } else {
    setting = await Setting.create(settingBody);
  }
  return setting;
};

module.exports = {
  getSettingInfo,
  updateSettingInfo,
};
