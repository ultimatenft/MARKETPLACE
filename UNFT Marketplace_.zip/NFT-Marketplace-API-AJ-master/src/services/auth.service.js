const httpStatus = require('http-status-codes');
const tokenService = require('./token.service');
const userService = require('./user.service');
const Token = require('../models/token.model');
const ApiError = require('../utils/ApiError');

/**
 * Login with username and password
 * @param {string} email
 * @param {string} password
 * @returns {Promise<User>}
 */
const loginUserWithEmailAndPassword = async (email, password) => {
  const user = await userService.getUserByEmail(email);
  if (!user || !(await user.isPasswordMatch(password))) {
    throw new ApiError(httpStatus.StatusCodes.UNAUTHORIZED, 'Incorrect email or password');
  } else if (user.status === 'INACTIVE') {
    throw new ApiError(
      httpStatus.StatusCodes.UNAUTHORIZED,
      'User is blocked temporarily. Please contact admin to activate this account'
    );
  }
  return user;
};

/**
 * Login with id and password
 * @param {string} id
 * @param {string} password
 * @returns {Promise<User>}
 */
const loginUserWithIdAndPassword = async (id, password) => {
  const user = await userService.getUserById(id);
  if (!user || !(await user.isPasswordMatch(password))) {
    throw new ApiError(httpStatus.StatusCodes.UNAUTHORIZED, 'Incorrect email or password');
  }
  return user;
};

/**
 * Logout
 * @param {string} refreshToken
 * @returns {Promise}
 */
const logout = async (refreshToken) => {
  const refreshTokenDoc = await Token.findOne({ token: refreshToken, type: 'refresh', blacklisted: false });
  if (!refreshTokenDoc) {
    throw new ApiError(httpStatus.StatusCodes.NOT_FOUND, 'Not found');
  }
  await refreshTokenDoc.remove();
};

/**
 * Refresh auth tokens
 * @param {string} refreshToken
 * @returns {Promise<Object>}
 */
const refreshAuth = async (refreshToken) => {
  try {
    const refreshTokenDoc = await tokenService.verifyToken(refreshToken, 'refresh');
    const user = await userService.getUserById(refreshTokenDoc.user);
    if (!user) {
      throw new Error();
    }
    await refreshTokenDoc.remove();
    return tokenService.generateAuthTokens(user);
  } catch (error) {
    throw new ApiError(httpStatus.StatusCodes.UNAUTHORIZED, 'Please authenticate');
  }
};

/**
 * Reset password
 * @param {string} resetPasswordToken
 * @param {string} newPassword
 * @returns {Promise}
 */
const resetPassword = async (resetPasswordToken, newPassword) => {
  try {
    const resetPasswordTokenDoc = await tokenService.verifyToken(resetPasswordToken, 'resetPassword');
    const user = await userService.getUserById(resetPasswordTokenDoc.user);
    if (!user) {
      throw new Error();
    }
    await Token.deleteMany({ user: user.id, type: 'resetPassword' });
    await userService.updateUserById(user.id, { password: newPassword });
  } catch (error) {
    throw new ApiError(httpStatus.StatusCodes.UNAUTHORIZED, 'Password reset failed');
  }
};

/**
 * Email Verification
 * @param {string} emailVerificationToken
 * @returns {Promise}
 */
const emailVerification = async (emailVerificationToken) => {
  try {
    const resetPasswordTokenDoc = await tokenService.verifyToken(emailVerificationToken, 'emailVerification');
    const user = await userService.getUserById(resetPasswordTokenDoc.user);
    if (!user) {
      throw new Error();
    }
    await Token.deleteMany({ user: user.id, type: 'emailVerification' });
    await userService.updateUserById(user.id, { is_email_verified: true });
  } catch (error) {
    throw new ApiError(httpStatus.StatusCodes.UNAUTHORIZED, 'Email verification failed');
  }
};

module.exports = {
  loginUserWithEmailAndPassword,
  loginUserWithIdAndPassword,
  logout,
  refreshAuth,
  resetPassword,
  emailVerification,
};
