const mongoose = require('mongoose');
// const validator = require('validator');
const slug = require('mongoose-slug-updater');
const { toJSON, paginate } = require('./plugins');

mongoose.plugin(slug);

const nftSchema = mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      required: true,
    },
    category: {
      type: String,
      required: true,
    },
    link: {
      type: String,
    },
    image: {
      type: String,
      required: true,
    },
    price: {
      type: Number,
      required: true,
    },
    fileType: {
      type: String,
      required: true,
      default: 'image/png',
    },
    attributes: [
      new mongoose.Schema(
        {
          trait_type: {
            type: String,
          },
          value: {
            type: String,
          },
        },
        { _id: false }
      ),
    ],
    slug: {
      type: String,
      slug: 'name',
      unique: true,
      index: true,
    },
    owner: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: 'User',
      required: true,
    },
    tokenId: {
      type: Number,
    },
    currentOwner: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: 'User',
      required: true,
    },
    currentOwnerWalletAddress: {
      type: String,
      required: true,
    },
    lockedUserId: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: 'User',
    },
    lockedExpiry: {
      type: Date,
    },
    status: {
      type: String,
      enum: ['AVAILABLE', 'SOLD', 'LOCKED'],
      default: 'AVAILABLE',
    },
    isFeatured: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
nftSchema.plugin(toJSON);
nftSchema.plugin(paginate);
nftSchema.index({ name: 'text', description: 'text' });

/**
 * @typedef Nft
 */
const Nft = mongoose.model('Nft', nftSchema);

module.exports = Nft;
