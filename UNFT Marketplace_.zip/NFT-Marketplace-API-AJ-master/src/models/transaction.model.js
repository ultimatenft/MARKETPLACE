const mongoose = require('mongoose');
const { toJSON } = require('./plugins');

const transactionSchema = mongoose.Schema(
  {
    nft: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: 'Nft',
      required: true,
    },
    user: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: 'User',
    },
    type: {
      type: String,
      required: true,
      enum: ['BUY', 'SELL', 'COMMISSION'],
    },
    percentage: {
      type: Number,
    },
    amount: {
      type: Number,
    },
    txnHash: {
      type: String,
    },
    transactionDetail: {
      type: Object,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
transactionSchema.plugin(toJSON);

/**
 * @typedef Transaction
 */
const Transaction = mongoose.model('Transaction', transactionSchema);

module.exports = Transaction;
