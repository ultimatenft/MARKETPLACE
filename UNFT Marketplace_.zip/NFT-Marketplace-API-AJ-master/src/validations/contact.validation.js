const Joi = require('@hapi/joi');
const { objectId } = require('./custom.validation');

const createContact = {
  body: Joi.object().keys({
    name: Joi.string().required(),
    email: Joi.string().required(),
    subject: Joi.string().required(),
    message: Joi.string().required(),
  }),
};

const getAllContacts = {
  query: Joi.object().keys({}),
};

const getContacts = {
  query: Joi.object().keys({
    name: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
  }),
};

const getContact = {
  params: Joi.object().keys({
    contactId: Joi.string().custom(objectId),
  }),
};

const updateContact = {
  params: Joi.object().keys({
    contactId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.string().required(),
      email: Joi.string().required(),
      subject: Joi.string().required(),
      message: Joi.string().required(),
    })
    .min(1),
};

const deleteContact = {
  params: Joi.object().keys({
    contactId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createContact,
  getAllContacts,
  getContacts,
  getContact,
  updateContact,
  deleteContact,
};
