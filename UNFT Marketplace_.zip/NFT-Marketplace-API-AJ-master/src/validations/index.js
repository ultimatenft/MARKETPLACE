module.exports.authValidation = require('./auth.validation');
module.exports.userValidation = require('./user.validation');
module.exports.nftValidation = require('./nft.validation');
module.exports.transactionValidation = require('./transaction.validation');
module.exports.contactValidation = require('./contact.validation');
