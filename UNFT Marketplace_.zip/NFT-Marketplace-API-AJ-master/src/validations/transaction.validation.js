const Joi = require('@hapi/joi');
const { objectId } = require('./custom.validation');

const createTransaction = {
  body: Joi.object().keys({
    user: Joi.string().required(),
    nft: Joi.string().required(),
    txnHash: Joi.string().required(),
    transactionDetail: Joi.required(),
  }),
};

const getAllTransactions = {
  query: Joi.object().keys(),
};

const getTransactions = {
  query: Joi.object().keys({
    name: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
  }),
};

const getTransaction = {
  params: Joi.object().keys({
    transactionId: Joi.string().custom(objectId),
  }),
};

const getTransactionByNftId = {
  params: Joi.object().keys({
    nftId: Joi.string().custom(objectId),
  }),
};

const updateTransaction = {
  params: Joi.object().keys({
    transactionId: Joi.required().custom(objectId),
  }),
  body: Joi.object().keys().min(1),
};

const deleteTransaction = {
  params: Joi.object().keys({
    transactionId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createTransaction,
  getAllTransactions,
  getTransactions,
  getTransaction,
  getTransactionByNftId,
  updateTransaction,
  deleteTransaction,
};
