const Joi = require('@hapi/joi');
const { objectId } = require('./custom.validation');

const createNft = {
  body: Joi.object().keys({
    name: Joi.string().required(),
    description: Joi.string().required(),
    image: Joi.string().required(),
    category: Joi.string().required(),
    link: Joi.allow(null, ''),
    fileType: Joi.allow(null, ''),
    attributes: Joi.allow(null, ''),
    price: Joi.number().required(),
    currentOwnerWalletAddress: Joi.string().required(),
    status: Joi.string().required(),
  }),
};

const getAllNfts = {
  query: Joi.object().keys({}),
};

const getNfts = {
  query: Joi.object().keys({
    name: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
  }),
};

const getNft = {
  params: Joi.object().keys({
    nftId: Joi.string().custom(objectId),
  }),
};

const updateNft = {
  params: Joi.object().keys({
    nftId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.string().required(),
      description: Joi.string().required(),
      category: Joi.string().required(),
      link: Joi.allow(null, ''),
      image: Joi.string().required(),
      attributes: Joi.allow(null, ''),
      currentOwnerWalletAddress: Joi.string().required(),
      status: Joi.string().required(),
    })
    .min(1),
};

const updateFeaturedNft = {
  params: Joi.object().keys({
    nftId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      isFeatured: Joi.bool().required(),
    })
    .min(1),
};

const deleteNft = {
  params: Joi.object().keys({
    nftId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createNft,
  getAllNfts,
  getNfts,
  getNft,
  updateNft,
  deleteNft,
  updateFeaturedNft,
};
