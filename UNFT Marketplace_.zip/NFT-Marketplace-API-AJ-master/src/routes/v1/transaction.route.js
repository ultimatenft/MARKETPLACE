const express = require('express');
const auth = require('../../middlewares/auth');
const validate = require('../../middlewares/validate');
const transactionValidation = require('../../validations/transaction.validation');
const transactionController = require('../../controllers/transaction.controller');

const router = express.Router();

router
  .route('/')
  .post(auth('manageUsers'), validate(transactionValidation.createTransaction), transactionController.createTransaction)
  .get(auth('manageUsers'), validate(transactionValidation.getTransactions), transactionController.getTransactions);

router
  .route('/all')
  .get(auth('manageUsers'), validate(transactionValidation.getAllTransactions), transactionController.getAllTransactions);

router
  .route('/commission/all')
  .get(
    auth('manageUsers'),
    validate(transactionValidation.getAllTransactions),
    transactionController.getAllCommisionAndRoyalities
  );

router
  .route('/nft/:nftId')
  .get(
    auth('manageUsers'),
    validate(transactionValidation.getTransactionByNftId),
    transactionController.getTransactionByNftId
  );

router
  .route('/:transactionId')
  .get(auth('manageUsers'), validate(transactionValidation.getTransaction), transactionController.getTransaction)
  .patch(auth('getUsers'), validate(transactionValidation.updateTransaction), transactionController.updateTransaction)
  .delete(auth('manageUsers'), validate(transactionValidation.deleteTransaction), transactionController.deleteTransaction);

module.exports = router;
