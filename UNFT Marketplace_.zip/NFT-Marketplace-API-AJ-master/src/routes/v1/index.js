const express = require('express');
const authRoute = require('./auth.route');
const userRoute = require('./user.route');
const docsRoute = require('./docs.route');
const nftRoute = require('./nft.route');
const transactionRoute = require('./transaction.route');
const contactRoute = require('./contact.route');

const router = express.Router();

router.use('/auth', authRoute);
router.use('/users', userRoute);
router.use('/docs', docsRoute);
router.use('/nfts', nftRoute);
router.use('/contacts', contactRoute);
router.use('/transactions', transactionRoute);

module.exports = router;
