const httpStatus = require('http-status-codes');
const pick = require('../utils/pick');
const ApiError = require('../utils/ApiError');
const catchAsync = require('../utils/catchAsync');
const { userService, settingService } = require('../services');

const createUser = catchAsync(async (req, res) => {
  if (req.user.role !== 'admin') {
    throw new ApiError(httpStatus.StatusCodes.UNAUTHORIZED, 'Not Authorized to perform this action');
  }
  const user = await userService.createUser(req.body);
  res.status(httpStatus.StatusCodes.CREATED).send(user);
});

const getAllUsers = catchAsync(async (req, res) => {
  const result = await userService.getAllUsers(req.user.email);
  res.send(result);
});

const getUsers = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role']);
  const options = pick(req.query, ['sortBy', 'limit', 'page']);
  const result = await userService.queryUsers(filter, options);
  res.send(result);
});

const getUser = catchAsync(async (req, res) => {
  const user = await userService.getUserById(req.params.userId);
  if (!user) {
    throw new ApiError(httpStatus.StatusCodes.NOT_FOUND, 'User not found');
  }
  res.send(user);
});

const updateUser = catchAsync(async (req, res) => {
  const user = await userService.updateUserById(req.params.userId, req.body);
  res.send(user);
});

const updatePassword = catchAsync(async (req, res) => {
  const user = await userService.updatePasswordById(req.params.userId, req.body);
  res.send(user);
});

const deleteUser = catchAsync(async (req, res) => {
  await userService.deleteUserById(req.params.userId);
  res.status(httpStatus.StatusCodes.NO_CONTENT).send();
});

const getUserProfileInfo = catchAsync(async (req, res) => {
  const result = await userService.getUserProfileInfo(req.user.id);
  res.send(result);
});

const updatePicture = catchAsync(async (req, res) => {
  const result = await userService.updatePicture(req.user.id, req.file.filename, req.body.type);
  res.send(result);
});

const getAdminDashboardData = catchAsync(async (req, res) => {
  const result = await userService.getAdminDashboardData(req.user.email);
  res.send(result);
});

const getAdminSetting = catchAsync(async (req, res) => {
  const result = await settingService.getSettingInfo();
  res.send(result);
});

const updateAdminSetting = catchAsync(async (req, res) => {
  const result = await settingService.updateSettingInfo(req.body);
  res.send(result);
});

const getArtistProfile = catchAsync(async (req, res) => {
  const result = await userService.getArtistProfile(req.params.userId);
  res.send(result);
});

module.exports = {
  createUser,
  getAllUsers,
  getUsers,
  getUser,
  updateUser,
  deleteUser,
  updatePassword,
  getUserProfileInfo,
  updatePicture,
  getAdminDashboardData,
  getAdminSetting,
  updateAdminSetting,
  getArtistProfile,
};
