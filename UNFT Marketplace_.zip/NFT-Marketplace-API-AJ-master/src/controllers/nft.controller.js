const httpStatus = require('http-status-codes');
const pick = require('../utils/pick');
const ApiError = require('../utils/ApiError');
const catchAsync = require('../utils/catchAsync');
const { nftService } = require('../services');

const createNft = catchAsync(async (req, res) => {
  const nft = await nftService.createNft(req.body, req.user);
  res.status(httpStatus.StatusCodes.CREATED).send(nft);
});

const getAllNfts = catchAsync(async (req, res) => {
  const result = await nftService.getAllNfts();
  res.send(result);
});

const getAllAvailableNfts = catchAsync(async (req, res) => {
  const isFeatured = req.query.isFeatured !== undefined ? req.query.isFeatured : 'false';
  const result = await nftService.getAllAvailableNfts(isFeatured);
  res.send(result);
});

const getNfts = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name']);
  const options = pick(req.query, ['sortBy', 'limit', 'page']);
  const result = await nftService.queryNfts(filter, options);
  res.send(result);
});

const getNft = catchAsync(async (req, res) => {
  const nft = await nftService.getNftById(req.params.nftId);
  if (!nft) {
    throw new ApiError(httpStatus.StatusCodes.NOT_FOUND, 'Nft not found');
  }
  res.send(nft);
});

const updateNft = catchAsync(async (req, res) => {
  const nft = await nftService.updateNftById(req.params.nftId, req.body);
  res.send(nft);
});

const deleteNft = catchAsync(async (req, res) => {
  await nftService.deleteNftById(req.params.nftId);
  res.status(httpStatus.StatusCodes.NO_CONTENT).send();
});

const checkiSNftAvailable = catchAsync(async (req, res) => {
  const result = await nftService.checkiSNftAvailable(req.params.nftId, req.user.id);
  res.send(result);
});

const releaseNFT = catchAsync(async (req, res) => {
  const result = await nftService.releaseNFT(req.params.nftId);
  res.send(result);
});

const buyNft = catchAsync(async (req, res) => {
  const nft = await nftService.buyNft(req.body);
  res.send(nft);
});

const releaseInProgressNftCron = catchAsync(async (req, res) => {
  const result = await nftService.releaseInProgressNftCron();
  res.send(result);
});

const searchNft = catchAsync(async (req, res) => {
  const result = await nftService.searchNft(req.params.text);
  res.send(result);
});

module.exports = {
  createNft,
  getAllNfts,
  getAllAvailableNfts,
  getNfts,
  getNft,
  updateNft,
  deleteNft,
  checkiSNftAvailable,
  releaseNFT,
  buyNft,
  releaseInProgressNftCron,
  searchNft,
};
