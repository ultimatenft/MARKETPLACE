const roles = ['user', 'artist', 'admin'];

const roleRights = new Map();
roleRights.set(roles[0], ['getUsers', 'getNfts', 'buyNfts']);
roleRights.set(roles[1], ['getUsers', 'getNfts', 'manageNfts', 'buyNfts']);
roleRights.set(roles[2], ['getUsers', 'manageUsers', 'getNfts', 'manageNfts', 'buyNfts', 'manageAdmin']);

module.exports = {
  roles,
  roleRights,
};
