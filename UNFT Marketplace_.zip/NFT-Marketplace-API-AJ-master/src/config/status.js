const status = ['pending', 'in progress', 'done'];

module.exports = {
  status,
};
