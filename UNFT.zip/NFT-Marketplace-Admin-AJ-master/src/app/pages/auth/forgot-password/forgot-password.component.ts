import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { AuthenticationService, UtilityService } from '../../../_services';
import { Router } from '@angular/router';

@Component({
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css'],
})
export class ForgotPasswordComponent implements OnInit {

  constructor(
    private authService: AuthenticationService,
    private utility: UtilityService,
    private formBuilder: FormBuilder,
    private router: Router
  ) {
    this.utility.updatePageSEO(
      'Forgot Password | NFT',
      'Forgot Password | NFT'
    );
  }

  public isLoader: boolean = false;
  public form: FormGroup = this.formBuilder.group({});

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      email: [
        null,
        [
          Validators.required,
          Validators.email,
          Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$'),
        ],
      ],
    });
  }

  get getForm() {
    return this.form.controls;
  }

  submitAction() {
    if (this.form.valid) {
      this.isLoader = true;
      this.authService.sendPasswordResetEmail(this.form.value.email).subscribe(
        (res) => {
          this.isLoader = false;
          this.utility.showToaster('Success!', 'Email Sent successfully');
          this.form.reset();
        },
        (error) => {
          this.isLoader = false;
          this.utility.showToaster('Error', error);
        }
      );
    }
  }
}
