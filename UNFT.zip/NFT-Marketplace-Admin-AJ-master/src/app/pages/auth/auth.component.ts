import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { AuthenticationService, UtilityService, ConnectService } from '../../_services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css'],
  providers: [ConnectService]
})
export class AuthComponent implements OnInit {

  constructor(private authService: AuthenticationService, private utility: UtilityService, private formBuilder: FormBuilder, private router: Router) {
    this.utility.updatePageSEO('Login | NFT', 'Login | NFT')
  }
  
  public isLoader: boolean = false;
  public form: FormGroup = this.formBuilder.group({})

  ngOnInit(): void {

    this.form = this.formBuilder.group({
      email: [null, [Validators.required, Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$')]],
      password: [null, Validators.required],
    });

  }

  get getForm() {
    return this.form.controls;
  }

  loginAction() {
    if (this.form.valid) {
      this.isLoader = true
      this.authService.login(this.form.value.email, this.form.value.password).subscribe(
        (res) => {
          this.isLoader = false;
          if(res['user']['role'] === 'admin'){
            this.utility.showToaster('Success!', 'Logged in successfully');
            this.router.navigate(['app/dashboard']);
          } else {
            this.utility.showToaster(
              'Error',
              'You have not permission to access'
            );
          }
        },
        (error) => {
          this.isLoader = false;
          this.utility.showToaster('Error', error);
        }
      );
    }
  }

}
