import { HomeComponent } from './home/home.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from './main.component';
import { NftListComponent } from './nft-list/nft-list.component';
import { NftDetailComponent } from './nft-detail/nft-detail.component';
import { ContactComponent } from './contact/contact.component';
import { UsersComponent } from './users/users.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { SettingsComponent } from './settings/settings.component';
import { TransactionComponent } from './transaction/transaction.component';
import { CommisionComponent } from './commision/commision.component';

const routes: Routes = [
  {
    path: '',
    component: MainComponent,
    children: [
      { path: 'dashboard', component: HomeComponent },
      { path: 'contacts', component: ContactComponent },
      { path: 'users', component: UsersComponent },
      { path: 'settings', component: SettingsComponent },
      { path: 'commisions', component: CommisionComponent },
      { path: 'transactions', component: TransactionComponent },
      { path: 'edit-profile', component: EditProfileComponent },
      { path: 'nft-list', component: NftListComponent },
      { path: 'nft-list/:smartContractId', component: NftListComponent },
      { path: 'nft-list/detail/:nftId', component: NftDetailComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MainRoutingModule { }
