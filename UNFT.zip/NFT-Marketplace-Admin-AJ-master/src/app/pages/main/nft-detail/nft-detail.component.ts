import { Component, OnInit, ViewChild } from '@angular/core';
import { UtilityService, NftService, BidService, TransactionService } from '../../../_services';
import { ActivatedRoute } from '@angular/router';
import { TransactionListItem, TransactionListDataSource } from './transaction-list-datasource';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';

@Component({
  templateUrl: './nft-detail.component.html',
  styleUrls: ['./nft-detail.component.css'],
})
export class NftDetailComponent implements OnInit {
  @ViewChild(MatPaginator) txnPaginator!: MatPaginator;
  @ViewChild('txnSort') txnSort!: MatSort;
  @ViewChild('txnTable') txnTable!: MatTable<TransactionListItem>;
  transactionDataSource: TransactionListDataSource;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = [
    'name',
    'email',
    'amount',
    'createdAt',
    'status',
    'action',
  ];
  txnDisplayedColumns = [
    'name',
    'email',
    'amount',
    'txnHash',
    'type',
    'createdAt',
  ];

  constructor(
    private nftService: NftService,
    private utility: UtilityService,
    private transactionService: TransactionService,
    private bidService: BidService,
    private _activatedRoute: ActivatedRoute
  ) {
    this.transactionDataSource = new TransactionListDataSource();
  }

  public nft: any = [];
  public bids: any = [];

  ngOnInit(): void {
    this.getNFTById(this._activatedRoute.snapshot.paramMap.get('nftId'));
    this.utility.updatePageSEO(
      'NFT Detail | NFT Marketplace',
      'NFT Detail | NFT Marketplace'
    );
  }

  getNFTById(id: any) {
    this.utility.startLoader();
    this.nftService.getNftById(id).subscribe(
      (res) => {
        this.nft = res;
        this.getAllTransactionsByNft(this.nft.id);
        this.utility.stopLoader();
      },
      (error) => {
        this.utility.stopLoader();
        this.utility.showToaster('Error', error);
      }
    );
  }

  getAllTransactionsByNft(id: any) {
    this.transactionService.getAllTransactionByNft(id).subscribe(
      (res) => {
        this.transactionDataSource = new TransactionListDataSource();
        this.transactionDataSource.data = res;
        this.transactionDataSource.sort = this.txnSort;
        this.transactionDataSource.paginator = this.txnPaginator;
        this.txnTable.dataSource = this.transactionDataSource;
      },
      (error) => {
        this.utility.showToaster('Error', error);
      }
    );
  }

  convertAmount(item: any) {
    return item.transactionDetail.events
      ? item.transactionDetail?.events?.Transfer?.returnValues?.value *
          Math.pow(10, -18)
      : 'NA';
  }

  getHTML() {
  
      return this.nft.description;

  }

  isNullOrWhiteSpace(str: string) {
    return !str || str.length === 0 || /^\s*$/.test(str);
  }
}
