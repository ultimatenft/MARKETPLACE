import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { UtilityService, ConnectService, UserService } from '../../../_services';

@Component({
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css'],
})
export class SettingsComponent implements OnInit {
  constructor(
    private utility: UtilityService,
    private formBuilder: FormBuilder,
    private connectService: ConnectService,
    private userService: UserService
  ) {}

  public isLoader: boolean = false;
  public feesForm: FormGroup = this.formBuilder.group({});

  ngOnInit(): void {

    this.feesForm = this.formBuilder.group({
      royalityShare: [0, [Validators.required]],
      platformFee: [null, [Validators.required]],
    });
    this.getAdminSetting()
  }

  getAdminSetting() {
    this.utility.startLoader();
    this.userService.getAdminSetting().subscribe(
      (res) => {
        this.utility.stopLoader();
        this.feesForm.patchValue({
          royalityShare: 0,
          platformFee: res.platformFee,
        });
      },
      (error) => {
        this.utility.stopLoader();
        this.utility.showToaster('Error', error);
      }
    );
  }

  updateAdminSetting() {
    this.utility.startLoader();
    this.userService.updateAdminSetting(this.feesForm.value).subscribe(
      (res) => {
        this.utility.stopLoader();

      },
      (error) => {
        this.utility.stopLoader();
        this.utility.showToaster('Error', error);
      }
    );
  }
}
