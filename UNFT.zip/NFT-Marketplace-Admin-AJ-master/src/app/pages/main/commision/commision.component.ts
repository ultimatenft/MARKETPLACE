import { OnInit, Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { CommisionDataSource, CommisionItem } from './commision-datasource';
import { UtilityService, TransactionService } from '../../../_services';

@Component({
  selector: 'app-commision',
  templateUrl: './commision.component.html',
  styleUrls: ['./commision.component.css'],
})
export class CommisionComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatTable) table!: MatTable<CommisionItem>;
  dataSource: CommisionDataSource;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = [
    'nft.tokenId',
    'user.email',
    'price',
    'type',
    'txnDetail',
  ];

  constructor(
    private utility: UtilityService,
    private transactionService: TransactionService
  ) {
    this.dataSource = new CommisionDataSource();
  }

  ngOnInit(): void {
    this.getAllCommisionAndRoyalities();
  }

  refreshTable() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }

  getAllCommisionAndRoyalities() {
    this.utility.startLoader();
    this.transactionService.getAllCommisionAndRoyalities().subscribe(
      (res) => {
        console.log(res);
        this.dataSource = new CommisionDataSource();
        this.dataSource.data = res;
        this.refreshTable();
        this.utility.stopLoader();
      },
      (error) => {
        this.utility.stopLoader();
        this.utility.showToaster('Error', error);
      }
    );
  }
}
