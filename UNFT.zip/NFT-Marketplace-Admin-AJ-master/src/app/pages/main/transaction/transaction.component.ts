import { OnInit, Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { TransactionDataSource, TransactionItem } from './transaction-datasource';
import { UtilityService, TransactionService } from '../../../_services';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css'],
})
export class TransactionComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatTable) table!: MatTable<TransactionItem>;
  dataSource: TransactionDataSource;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = [
    'nft.tokenId',
    'user.email',
    'price',
    'type',
    'txnDetail',
  ];

  constructor(
    private utility: UtilityService,
    private transactionService: TransactionService
  ) {
    this.dataSource = new TransactionDataSource();
  }

  ngOnInit(): void {
    this.getAllTransactions();
  }

  refreshTable() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }

  getAllTransactions() {
    this.utility.startLoader();
    this.transactionService.getAllTransactions().subscribe(
      (res) => {
        console.log(res);
        this.dataSource = new TransactionDataSource();
        this.dataSource.data = res;
        this.refreshTable();
        this.utility.stopLoader();
      },
      (error) => {
        this.utility.stopLoader();
        this.utility.showToaster('Error', error);
      }
    );
  }
}
