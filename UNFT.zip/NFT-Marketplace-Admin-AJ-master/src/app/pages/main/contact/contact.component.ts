import { OnInit, Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { ContactDataSource, ContactItem } from './contact-datasource';
import { UtilityService, ContactService } from '../../../_services';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css'],
})
export class ContactComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatTable) table!: MatTable<ContactItem>;
  dataSource: ContactDataSource;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['email', 'name', 'subject', 'message', 'createdAt'];

  constructor(
    private contactService: ContactService,
    private utility: UtilityService
  ) {
    this.dataSource = new ContactDataSource();
  }

  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    this.getAllContactRequest();
  }

  refreshTable() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }

  getAllContactRequest() {
    this.utility.startLoader();
    this.contactService.getAllContactRequests().subscribe(
      (res) => {
        this.dataSource = new ContactDataSource();
        this.dataSource.data = res;
        this.refreshTable();
        this.utility.stopLoader();
      },
      (error) => {
        this.utility.stopLoader();
        this.utility.showToaster('Error', error);
      }
    );
  }
}
