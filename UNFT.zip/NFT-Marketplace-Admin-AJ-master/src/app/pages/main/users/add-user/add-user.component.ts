import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {
  UserService,
  UtilityService,
} from '../../../../_services';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css'],
})
export class AddUserComponent implements OnInit {
  constructor(
    private formBuilder: FormBuilder,
    private utility: UtilityService,
    private userService: UserService,
    public dialogRef: MatDialogRef<AddUserComponent>
  ) {}

  public isLoader: boolean = false;
  public form: FormGroup = this.formBuilder.group({});

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      name: [null, Validators.required],
      role: [null, Validators.required],
      email: [null, [Validators.required, Validators.email]],
      is_email_verified: [true, Validators.required],
      password: ['Admin@123', Validators.required],
    });
  }

  get getForm() {
    return this.form.controls;
  }

  async submitAction() {
    
    this.isLoader = true;
    this.userService.createUser(this.form.value).subscribe(
      (res) => {
        this.isLoader = false;
        this.utility.showToaster('Success', 'User created successfully');
        this.dialogRef.close('success');
      },
      (error) => {
        this.isLoader = false;
        this.utility.showToaster('Error', error);
      }
    );
  }
}
