import { Component, OnInit, Input, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService, UtilityService } from '../../../../_services';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css'],
})
export class EditUserComponent implements OnInit {
  constructor(
    private formBuilder: FormBuilder,
    private utility: UtilityService,
    private userService: UserService,
    public dialogRef: MatDialogRef<EditUserComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  public isLoader: boolean = false;
  public form: FormGroup = this.formBuilder.group({});

  ngOnInit(): void {
    console.log(this.data);

    this.form = this.formBuilder.group({
      name: [this.data.user.name, Validators.required],
      role: [this.data.user.role, Validators.required],
      email: [this.data.user.email, [Validators.required, Validators.email]],
      status: [this.data.user.status, [Validators.required]],
    });
  }

  get getForm() {
    return this.form.controls;
  }

  async submitAction() {
    this.isLoader = true;
    this.userService.updateUser(this.data.user.id, this.form.value).subscribe(
      (res) => {
        this.isLoader = false;
        this.utility.showToaster('Success', 'User Updated successfully');
        this.dialogRef.close('success');
      },
      (error) => {
        this.isLoader = false;
        this.utility.showToaster('Error', error);
      }
    );
  }
}
