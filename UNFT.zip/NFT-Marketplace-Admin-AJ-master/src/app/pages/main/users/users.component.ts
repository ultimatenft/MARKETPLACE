import { Component, ViewChild, OnInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import {
  UsersDataSource,
  UserItem,
} from './users-datasource';
import { UtilityService, UserService } from '../../../_services';
import { MatDialog } from '@angular/material/dialog';
import { AddUserComponent } from './add-user/add-user.component';
import { EditUserComponent } from './edit-user/edit-user.component';

@Component({
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
})
export class UsersComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatTable) table!: MatTable<UserItem>;
  dataSource: UsersDataSource;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = [
    'name',
    'email',
    'is_email_verified',
    'role',
    'status',
    'createdAt',
    'action',
  ];
  public isLoader: boolean = false;

  constructor(
    private userService: UserService,
    private utility: UtilityService,
    public dialog: MatDialog
  ) {
    this.dataSource = new UsersDataSource();
  }

  ngOnInit(): void {
    this.getAllUsers();
  }

  openDialog() {
    const dialogRef = this.dialog.open(AddUserComponent, {
      width: '400px',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'success') {
        this.getAllUsers();
      }
    });
  }

  openEditUserDialog(user: any) {
    const dialogRef = this.dialog.open(EditUserComponent, {
      width: '400px',
      data: {
        user: user,
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'success') {
        this.getAllUsers();
      }
    });
  }

  refreshTable() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }

  getAllUsers() {
    this.isLoader = true;
    this.userService.getUsers().subscribe(
      (res) => {
        this.dataSource = new UsersDataSource();
        this.dataSource.data = res;
        this.refreshTable();
        this.isLoader = false;
      },
      (error) => {
        this.isLoader = false;
        this.utility.showToaster('Error', error);
      }
    );
  }
}
