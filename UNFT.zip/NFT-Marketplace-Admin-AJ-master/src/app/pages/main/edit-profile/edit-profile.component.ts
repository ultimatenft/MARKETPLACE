import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { UtilityService, UserService } from '../../../_services';
import { ActivatedRoute, Router } from '@angular/router';
import { MustMatch } from '../../../_helpers/mustMatch.validator';

@Component({
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css'],
})
export class EditProfileComponent implements OnInit {
  constructor(
    private userService: UserService,
    private utility: UtilityService,
    private formBuilder: FormBuilder,
    private _activatedRoute: ActivatedRoute,
    private _Router: Router
  ) {}

  public isLoader: boolean = false;
  public form: FormGroup = this.formBuilder.group({});
  public changePasswordForm: FormGroup = this.formBuilder.group({});
  public userProfile: any = [];

  ngOnInit(): void {
    this.getProfileInfo();
    this.changePasswordForm = this.formBuilder.group(
      {
        password: ['', [Validators.required, Validators.minLength(6)]],
        confirm_password: ['', [Validators.required, Validators.minLength(6)]],
      },
      {
        validator: [MustMatch('password', 'confirm_password')],
      }
    );
  }

  get getForm() {
    return this.form.controls;
  }

  get getChangePasswordForm() {
    return this.changePasswordForm.controls;
  }

  getProfileInfo() {
    const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
    this.userService.getUserById(currentUser.id).subscribe(
      (res) => {
        this.userProfile = res;
        this.form = this.formBuilder.group({
          name: [this.userProfile.name, [Validators.required]],
          email: [this.userProfile.email, [Validators.required]],
        });
      },
      (error) => {
        this.utility.showToaster('Error', error);
      }
    );
  }

  submitAction() {
    this.updateUserInfo(this.form.value);
  }

  updatePassword() {
    this.updateUserInfo({ password: this.changePasswordForm.value.password });
    this.changePasswordForm.reset();
  }

  updateUserInfo(data: any) {
    const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
    this.userService.updateUser(currentUser.id, data).subscribe(
      (res) => {
        this.userProfile = res;
        this.form = this.formBuilder.group({
          name: [this.userProfile.name, [Validators.required]],
          email: [this.userProfile.email, [Validators.required]],
        });
        this.utility.showToaster(
          'Success',
          'User Information Updated Successfully'
        );
      },
      (error) => {
        this.utility.showToaster('Error', error);
      }
    );
  }
}
