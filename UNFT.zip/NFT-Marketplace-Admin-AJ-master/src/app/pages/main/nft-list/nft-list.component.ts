import { OnInit, Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { NftListDataSource, NftListItem } from './nft-list-datasource';
import { UtilityService, NftService } from '../../../_services';
import { MatDialog } from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-nft-list',
  templateUrl: './nft-list.component.html',
  styleUrls: ['./nft-list.component.css'],
})
export class NftListComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatTable) table!: MatTable<NftListItem>;
  dataSource: NftListDataSource;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = [
    'createdAt',
    'currentOwner',
    'name',
    'image',
    'price',
    'status',
    'featured',
    'action',
  ];
  public isLoader: boolean = false;
  public form: FormGroup = this.formBuilder.group({});
  public smartContracts: any = [];
  public allNfts: any = [];
  public uriResponse: any = [];

  constructor(
    public dialog: MatDialog,
    private nftService: NftService,
    private utility: UtilityService,
    private formBuilder: FormBuilder,
    private _ActivatedRoute: ActivatedRoute
  ) {
    this.dataSource = new NftListDataSource();
  }

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      address: [null, Validators.required],
    });

    this.getAllNfts();
  }

  refreshTable() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }

  getAllNfts() {
    this.isLoader = true;
    this.nftService.getAllNfts().subscribe(
      (res) => {
        this.allNfts = res;

        this.dataSource = new NftListDataSource();
        this.dataSource.data = res;
        this.refreshTable();
        this.isLoader = false;
      },
      (error) => {
        this.isLoader = false;
        this.utility.showToaster('Error', error);
      }
    );
  }

  deleteNFTConfirmation(id: String) {
    Swal.fire({
      title: 'Confirm!',
      text: 'Do you want to delete this NFT ?',
      icon: 'question',
      confirmButtonText: 'Proceed',
      showCloseButton: true,
      cancelButtonText: 'Cancel',
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        this.deleteNft(id);
      }
    });
  }

  deleteNft(id: String) {
    this.utility.startLoader();
    this.nftService.deleteNft(id).subscribe(
      (res) => {
        this.utility.stopLoader();
        this.getAllNfts();
      },
      (error) => {
        this.utility.stopLoader();
        this.utility.showToaster('Error', error);
      }
    );
  }

  filterData() {
    if (this.form.value.address !== 'All' && this.form.value.address !== '') {
      this.dataSource = new NftListDataSource();
      this.dataSource.data = this.allNfts.filter((element: any) => {
        return element.contract.contract === this.form.value.address;
      });
      this.refreshTable();
    } else if (this.form.value.address === 'All') {
      this.dataSource = new NftListDataSource();
      this.dataSource.data = this.allNfts;
      this.refreshTable();
    }
  }

  changeSlide(row:any) {
    console.log(row);
    this.utility.startLoader();
    this.nftService
      .updateFeatured(row.id, { isFeatured: !row.isFeatured })
      .subscribe(
        (res) => {
          this.utility.stopLoader();
          this.getAllNfts();
        },
        (error) => {
          this.utility.stopLoader();
          this.utility.showToaster('Error', error);
        }
      );
  }
}
