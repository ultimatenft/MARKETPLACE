import { Component } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { UtilityService, AuthenticationService } from '../../_services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent {
  isHandset$: Observable<boolean> = this.breakpointObserver
    .observe(Breakpoints.Handset)
    .pipe(
      map((result) => result.matches),
      shareReplay()
    );

  constructor(
    private breakpointObserver: BreakpointObserver,
    private utility: UtilityService,
    private authService: AuthenticationService,
    private router: Router
  ) {}

  logoutAction() {
    this.authService.logout().subscribe(
      (res) => {
        this.utility.showToaster('Success!', 'Logout Successfully');
        this.router.navigate(['/auth/login']);
       // window.location.href = 'http://167.99.51.160/admin';
      },
      (error) => {
        this.utility.showToaster('Error', error);
      }
    );
  }
}
