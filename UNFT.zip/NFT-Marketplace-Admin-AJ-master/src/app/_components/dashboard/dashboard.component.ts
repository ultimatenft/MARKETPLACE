import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs/operators';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { UtilityService, UserService } from '../../_services';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  /** Based on the screen size, switch from standard to one column per row */
  cards = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
    map(({ matches }) => {
      return [
        { title: 'Total Users', cols: 1, rows: 1, key: 'users' },
        { title: 'Total NFTs', cols: 1, rows: 1, key: 'nfts' },
        { title: 'Total Contact Request', cols: 1, rows: 1, key: 'contacts' },
        { title: 'Total Sold NFTs', cols: 1, rows: 1, key: 'solds' },
      ];
    })
  );

  public dashboard: any = { users: 1, contacts: 1, solds: 1, nfts : 1};

  constructor(
    private breakpointObserver: BreakpointObserver,
    private _UserService: UserService,
    private utility: UtilityService
  ) {}

  ngOnInit(): void {
    this.getAllContactRequest();
  }

  getAllContactRequest() {
    this.utility.startLoader();
    this._UserService.getAdminDashboardData().subscribe(
      (res) => {
        this.dashboard = res;
        this.utility.stopLoader();
      },
      (error) => {
        this.utility.stopLoader();
        this.utility.showToaster('Error', error);
      }
    );
  }
}
