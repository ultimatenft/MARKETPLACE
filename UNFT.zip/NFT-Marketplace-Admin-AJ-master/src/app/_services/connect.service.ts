import { environment } from './../../environments/environment';
import { Injectable } from '@angular/core';
const Web3 = require('web3');
declare let require: any;
declare let window: any;
const tokenAbi = require('../contract/abis.json');

@Injectable({
  providedIn: 'root',
})
export class ConnectService {
  private account: any = null;
  private readonly web3: any;
  private enable: any;
  private contract: any;

  constructor() {
    if (window.ethereum === undefined) {
      alert('Non-Ethereum browser detected. Install MetaMask');
    } else {
      if (typeof window.web3 !== 'undefined') {
        this.web3 = window.web3.currentProvider;
      } else {
        this.web3 = new Web3.providers.HttpProvider('http://localhost:8545');
      }

      console.log('transfer.service :: constructor :: window.ethereum');
      window.web3 = new Web3(window.ethereum);
      console.log('transfer.service :: constructor :: this.web3');
      console.log(this.web3);
      this.enable = this.enableMetaMaskAccount();
      console.log(this.enable);
    }
  }

  private async enableMetaMaskAccount(): Promise<any> {
    let enable = false;
    await new Promise(async (resolve, reject) => {
      if (window.ethereum) {
        enable = await window.ethereum.enable();

        if (enable) {
          this.getUserBalance();
          // this.connectContract();
        }
      }
    });
    return Promise.resolve(enable);
  }

  public async convertJSONtoHEX(value: any) {
    return window.web3.utils.toHex(value);
  }

  public async connectContract(address: any) {
    try {
      this.contract = await new window.web3.eth.Contract(tokenAbi, address);
    } catch (error) {
      console.log(error);
      return error
    }
  }

  public async createPropertyNFTs(id: any, acres: any, byteData: any) {
    // var contract = await this.connectContract();
    var receipt = await this.contract.methods
      .createToken([id], [acres], byteData)
      .send({ from: this.account })
      .once('receipt', (receipt: any) => {
        console.log('receipt==========', receipt);
      })
      .catch((error: any) => {
        return error
      });

    return receipt;
  }

  public async getTotalSupply(address: any) {
    let jsonData = [];
    const error = await this.connectContract(address);
    console.log(this.contract);
    
    if(this.contract){
      var symbol = await this.contract.methods.symbol().call();
      
      var name = await this.contract.methods.name().call();
      var supply = await this.contract.methods.totalSupply().call();
      console.log(supply);
      
      for (let index = 1; index <= supply; index++) {
        let currentOwnerWalletAddress = await this.contract.methods
          .ownerOf(index)
          .call();
        console.log(index);
        console.log(currentOwnerWalletAddress);
        const uri = await this.getTokenDetails(index);
        if(uri){
          jsonData.push({
            symbol: symbol,
            name: name,
            uri: uri,
            currentOwnerWalletAddress: currentOwnerWalletAddress,
            supply: supply,
            contract: address,
            tokenId: index,
          });
        }
      }

      return jsonData;
    } else {
      return error.message;
    }
  }

  async getTokenDeatil(address: any, nftId: any) {
    await this.connectContract(address);
    const symbol = await this.contract.methods.symbol().call();
    const name = await this.contract.methods.name().call();
    const uri = await this.getTokenDetails(nftId);
    return{symbol, name, uri}
  }

  async getTokenCount(address: any) {
    await this.connectContract(address);
    var supply = await this.contract.methods.totalSupply().call();
    return supply;
  }

  public async getTokenDetails(id: number) {
    try {
      var uri = await this.contract.methods.tokenURI(id).call();
      return uri;
    } catch (error) {
      return undefined;
    }
  }

  public async getTotalTransactionCount() {
    const total = await window.web3.eth.getTransactionCount(environment.PLATFORM_OWNER_ADDRESS, 'pending')
    console.log(total);
    return total
  }

  private async getAccount(): Promise<any> {
    console.log('transfer.service :: getAccount :: start');
    if (this.account == null) {
      this.account = (await new Promise((resolve, reject) => {
        console.log('transfer.service :: getAccount :: eth');
        console.log(window.web3.eth);
        window.web3.eth.getAccounts((err: null, retAccount: string | any[]) => {
          console.log('transfer.service :: getAccount: retAccount');
          console.log(retAccount);
          console.log(err);
          if (retAccount.length > 0) {
            this.account = retAccount[0];
            resolve(this.account);
          } else {
            alert('transfer.service :: getAccount :: no accounts found.');
            reject('No accounts found.');
          }
          if (err != null) {
            alert('transfer.service :: getAccount :: error retrieving account');
            reject('Error retrieving account');
          }
        });
      })) as Promise<any>;
    }
    return Promise.resolve(this.account);
  }
  public async getUserBalance(): Promise<any> {
    const account = await this.getAccount();
    console.log('transfer.service :: getUserBalance :: account');
    console.log(account);
    return new Promise((resolve, reject) => {
      window.web3.eth.getBalance(account, function (err: any, balance: any) {
        console.log('transfer.service :: getUserBalance :: getBalance');
        console.log(balance);
        if (!err) {
          const retVal = {
            account: account,
            balance: balance,
          };
          console.log(
            'transfer.service :: getUserBalance :: getBalance :: retVal'
          );
          console.log(retVal);
          resolve(retVal);
        } else {
          reject({ account: 'error', balance: 0 });
        }
      });
    }) as Promise<any>;
  }

  public async getWalletBlalnce() {
    const balanceNFT = await this.contract.methods
      .balanceOf(environment.PLATFORM_OWNER_ADDRESS, 1)
      .call();

    console.log('balanceNFT info ', balanceNFT);
  }

  public async transferOwnership(address: any) {
    var response = await this.contract.methods
      .transferOwnership(address)
      .send({ from: this.account })
      .once('receipt', (receipt: any) => {
        console.log('receipt==========', receipt);
      })
      .catch((error: any) => {
        console.log('error==========', error);
      });
    return response;
  }
}
