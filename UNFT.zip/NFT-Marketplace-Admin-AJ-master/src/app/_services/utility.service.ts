import { Injectable, Output, EventEmitter } from '@angular/core';
import { PageService } from 'ngx-seo-page';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import { MatSpinner } from '@angular/material/progress-spinner';

@Injectable({
  providedIn: 'root',
})
export class UtilityService {
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  @Output() loader_callback: EventEmitter<any> = new EventEmitter();
  private spinnerRef: OverlayRef = this.cdkSpinnerCreate();
  constructor(
    private seoService: PageService,
    private _snackBar: MatSnackBar,
    private overlay: Overlay
  ) {}

  private cdkSpinnerCreate() {
    return this.overlay.create({
      hasBackdrop: true,
      backdropClass: 'dark-backdrop',
      positionStrategy: this.overlay
        .position()
        .global()
        .centerHorizontally()
        .centerVertically(),
    });
  }

  getItem(key: string) {
    return localStorage.getItem(key);
  }

  setItem(key: string, value: string) {
    localStorage.setItem(key, value);
  }

  deleteItem(key: string) {
    localStorage.removeItem(key);
  }

  startLoader(text = 'Loading...') {
    this.spinnerRef.attach(new ComponentPortal(MatSpinner));
  }

  stopLoader() {
     this.spinnerRef.detach();
  }


  updatePageSEO(
    title: string,
    name: string,
    url: string = '',
    image: string = ''
  ) {
    this.seoService.updatePage({
      title: title,
      schema: {
        '@type': 'WebSite',
        name: name,
        url: window.location.host,
      },
      metatags: [
        { name: 'description', content: name },
        { property: 'og:url', content: url },
        { property: 'og:title', content: title },
      ],
      canonical: window.location.host,
    });
  }

  showToaster(title = 'Error', description: string) {
    this._snackBar.open(description, title, {
      duration: 3000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    });
  }
 
}
