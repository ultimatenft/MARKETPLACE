import { Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root',
})
export class NftService {
  public readonly apiUrl = environment.API_BASE_URL;

  constructor(public http: HttpClient, public sanitizer: DomSanitizer) {
    // set token if saved in local storage
  }

  // sync New  Nft
  syncNft(nftBody: any) {
    return this.http.post(`${this.apiUrl}nfts/sync-nft`, nftBody).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  // Get all nft list
  getAllNfts() {
    return this.http.get(`${this.apiUrl}nfts/all`).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  // Get nft by id
  getNftById(nftId: String) {
    return this.http.get(`${this.apiUrl}nfts/${nftId}`).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  // update NFT
  updateNFT(nftId: any, nftBody: Object) {
    return this.http.patch(`${this.apiUrl}nfts/${nftId}`, nftBody).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  // update featured  NFT
  updateFeatured(nftId: any, nftBody: Object) {
    return this.http
      .patch(`${this.apiUrl}nfts/update-featured-nft/${nftId}`, nftBody)
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  // Delete Nft
  deleteNft(nftId: String) {
    return this.http.delete(`${this.apiUrl}nfts/${nftId}`).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

}
