import { Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable()
export class UserService {
  public readonly apiUrl = environment.API_BASE_URL;

  constructor(public http: HttpClient, public sanitizer: DomSanitizer) {
    // set token if saved in local storage
  }

  // create user
  createUser(userBody: any) {
    return this.http.post(`${this.apiUrl}users`, userBody).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  // Get all user list role wise
  getUsers() {
    return this.http.get(`${this.apiUrl}users/all`).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  // Get all dashboard data
  getAdminDashboardData() {
    return this.http.get(`${this.apiUrl}users/dashboard-data`).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  // Get admin setting data
  getAdminSetting() {
    return this.http.get(`${this.apiUrl}users/get-admin-setting`).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  // Get admin setting data
  updateAdminSetting(data: any) {
    return this.http
      .patch(`${this.apiUrl}users/update-admin-setting`, data)
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  // Get user by id
  getUserById(userId: String) {
    return this.http.get(`${this.apiUrl}users/${userId}`).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  // Add New User
  updateUser(userId: String, userBody: Object) {
    return this.http.patch(`${this.apiUrl}users/${userId}`, userBody).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  // Delete User
  deleteUser(userId: String) {
    return this.http.delete(`${this.apiUrl}users/${userId}`).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
}
