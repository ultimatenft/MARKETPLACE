import { Observable } from 'rxjs/internal/Observable';
import { Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class TransactionService {
  public readonly apiUrl = environment.API_BASE_URL;

  constructor(public http: HttpClient, public sanitizer: DomSanitizer) {
    // set token if saved in local storage
  }

  // get all transactions by nft
  getAllTransactionByNft(nftId: string) {
    return this.http.get(`${this.apiUrl}transactions/nft/${nftId}`).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  // get all commissions & Royalities
  getAllCommisionAndRoyalities() {
    return this.http.get(`${this.apiUrl}transactions/commission/all`).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  // get all Transactions
  getAllTransactions() {
    return this.http.get(`${this.apiUrl}transactions/all`).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
}
