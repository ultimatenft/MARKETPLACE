import { Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class BidService {
  public readonly apiUrl = environment.API_BASE_URL;

  constructor(public http: HttpClient, public sanitizer: DomSanitizer) {
    // set token if saved in local storage
  }

  // get all bids by nft
  getAllBidsByNft(nft: string) {
    return this.http.get(`${this.apiUrl}bids/nft/all/${nft}`).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  // delete bid
  deleteBid(bidId: string) {
    return this.http.delete(`${this.apiUrl}bids/${bidId}`).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
}
