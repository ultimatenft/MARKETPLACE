// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  API_BASE_URL: 'http://147.182.187.164:3001/v1/',
  CONTRACT_ADDRESS: '0xaf49F92B39F22547BeaD17dDcfde18F1C662F3dD',
  PLATFORM_OWNER_ADDRESS: '0x631822399789E4BcFa1EfF1dffBf07cb99441FDC',
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
