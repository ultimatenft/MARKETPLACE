export const environment = {
  production: true,
  API_BASE_URL: 'https://api.defynft.com/v1/',
  CONTRACT_ADDRESS: '0xe9e7cea3dedca5984780bafc599bd69add087d56',
  PLATFORM_OWNER_ADDRESS: '0x631822399789E4BcFa1EfF1dffBf07cb99441FDC',
};
